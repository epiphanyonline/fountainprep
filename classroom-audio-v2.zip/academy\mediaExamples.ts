export const academyStoryByActivity: Record<string, string> = {
  "personal-finance-money-value": 
    "A young learner receives £10. They can spend all of it today, save part for something important, or use part to create something they can sell. The lesson is not that one choice is always correct — it is that every choice has a trade-off.",
  "personal-finance-saving":
    "Madam C. J. Walker built a business by identifying a real need, developing a product and building a sales network. Her story can help learners discuss value creation, enterprise, reinvestment and what it means to turn skills into productive assets.",
  "personal-finance-investing":
    "Imagine two young adults starting with the same income. One spends every increase in pay; the other gradually builds an emergency fund and buys productive assets. Over time, their choices create very different levels of resilience and opportunity.",
};

export function storyForActivity(
  academyCode: string,
  activityId: string,
): string | null {
  return (
    academyStoryByActivity[`${academyCode}-${activityId}`] ??
    null
  );
}
