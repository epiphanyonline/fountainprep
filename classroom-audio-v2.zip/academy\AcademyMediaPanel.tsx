"use client";

import { useCallback, useEffect, useState } from "react";

type Props = {
  title: string;
  text: string;
  visualLabel?: string | null;
  story?: string | null;
};

export default function AcademyMediaPanel({
  title,
  text,
  visualLabel,
  story,
}: Props) {
  const [speaking, setSpeaking] = useState(false);

  const stop = useCallback(() => {
    if (typeof window === "undefined") return;
    window.speechSynthesis.cancel();
    setSpeaking(false);
  }, []);

  useEffect(() => stop, [stop]);

  function hearLesson() {
    if (typeof window === "undefined") return;

    stop();

    const utterance = new SpeechSynthesisUtterance(
      `${title}. ${text}${story ? `. ${story}` : ""}`,
    );

    utterance.rate = 0.94;
    utterance.pitch = 1;
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);

    setSpeaking(true);
    window.speechSynthesis.speak(utterance);
  }

  return (
    <section className="mediaPanel">
      <div className="visualStage">
        <div className="visualMark">
          {visualLabel || "Learning visual"}
        </div>
        <div className="visualRings">
          <span />
          <span />
          <span />
        </div>
      </div>

      {story ? (
        <div className="storyCard">
          <small>REAL-LIFE STORY / CASE</small>
          <p>{story}</p>
        </div>
      ) : null}

      <div className="mediaActions">
        <button type="button" onClick={hearLesson} disabled={speaking}>
          {speaking ? "Speaking…" : "🔊 Hear explanation"}
        </button>
        {speaking ? (
          <button type="button" onClick={stop}>
            Stop
          </button>
        ) : null}
      </div>

      <style jsx>{`
        .mediaPanel {
          display:grid;
          gap:14px;
          margin-top:22px;
        }

        .visualStage {
          position:relative;
          min-height:180px;
          display:grid;
          place-items:center;
          overflow:hidden;
          border:1px solid rgba(124,58,237,.12);
          border-radius:24px;
          background:
            radial-gradient(circle at 50% 50%,rgba(124,58,237,.16),transparent 34%),
            linear-gradient(135deg,#fbf8ff,#f3edff);
        }

        .visualMark {
          position:relative;
          z-index:2;
          max-width:72%;
          padding:14px 18px;
          border-radius:18px;
          color:#5b21b6;
          background:rgba(255,255,255,.92);
          box-shadow:0 12px 34px rgba(65,37,98,.12);
          font-weight:950;
          text-align:center;
        }

        .visualRings {
          position:absolute;
          inset:0;
          display:grid;
          place-items:center;
        }

        .visualRings span {
          position:absolute;
          width:110px;
          height:110px;
          border:1px solid rgba(124,58,237,.13);
          border-radius:50%;
        }

        .visualRings span:nth-child(2){width:180px;height:180px;}
        .visualRings span:nth-child(3){width:260px;height:260px;}

        .storyCard {
          padding:18px;
          border-radius:20px;
          background:#fff8e8;
          border:1px solid rgba(180,125,0,.14);
        }

        .storyCard small {
          color:#9a6700;
          font-weight:950;
          letter-spacing:.08em;
        }

        .storyCard p {
          margin:8px 0 0;
          color:#584c39;
          line-height:1.65;
        }

        .mediaActions {
          display:flex;
          flex-wrap:wrap;
          gap:9px;
        }

        .mediaActions button {
          min-height:44px;
          padding:0 16px;
          border:0;
          border-radius:14px;
          color:#5b21b6;
          background:#f2eaff;
          font-weight:900;
          cursor:pointer;
        }

        .mediaActions button:disabled {
          opacity:.65;
          cursor:wait;
        }
      `}</style>
    </section>
  );
}
