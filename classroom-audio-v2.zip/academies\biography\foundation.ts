export const biographyFoundation = {
  id: "greatness-foundation",
  title: "Biography of Greatness",
  freeStories: [
    {
      id: "nelson-mandela",
      title: "Nelson Mandela",
      theme: "Courage, endurance and reconciliation",
      slideSequence: [
        "The world he was born into",
        "Education and early choices",
        "The cost of resistance",
        "Years of imprisonment",
        "Choosing reconciliation",
        "Impact and legacy",
        "What courage can look like in your own life",
      ],
    },
  ],
  premiumStories: [
    "Marie Curie",
    "Katherine Johnson",
    "Wangari Maathai",
    "Madam C. J. Walker",
    "Leonardo da Vinci",
    "Martin Luther King Jr.",
    "Malala Yousafzai",
  ],
} as const;
